package com.example.cafe40
data class Coffee(
    val name: String? = null,
    val img: String? = null,
    val description: String? = null
)
