package com.example.cafe40

data class ChatMessage(
    val sender: String? = null,
    val message: String? = null
)
